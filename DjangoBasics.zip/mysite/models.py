from django.db import models

class deta:
  name:str
  action:str
